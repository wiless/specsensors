#ifndef delay_H
#define	delay_H

#include <xc.h> 

void delay(unsigned long int count);

#endif

